﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EasyExploits;

namespace Beansploit
{
    public partial class Script_Hub : Form
    {
        public Script_Hub()
        {
            InitializeComponent();
        }
        Point lastPoint;
        EasyExploits.Module module = new EasyExploits.Module();
        private void Script_Hub_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Script_Hub_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void Script_Hub_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            module.ExecuteScript("loadstring(game:HttpGet(('https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source'),true))()");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            module.ExecuteScript("loadstring(game:HttpGet(('https://raw.githubusercontent.com/RandomAdamYT/DarkHub/master/Init'), true))()");

        }

        private void button3_Click(object sender, EventArgs e)
        {
            module.ExecuteScript("loadstring?(game:HttpGet(('https://pastebin.com/raw/9RjsRgnw'), true))()");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            module.ExecuteScript("loadstring?(game:HttpGet(('https://pastebin.com/raw/wDAriVcb'), true))()");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            module.ExecuteScript("loadstring?(game:HttpGet(('https://pastebin.com/raw/hMbvfh8x'), true))()");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            module.ExecuteScript("loadstring(game:HttpGet(('https://pastebin.com/raw/3f5ANHeW'), true))()");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button8_Click(object sender, EventArgs e)
        {

            WindowState = FormWindowState.Minimized;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void label1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }
    }
}
